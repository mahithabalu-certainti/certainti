export { default as Resources } from './resources';
