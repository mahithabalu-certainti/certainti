import React from 'react';
import { adminSubmenuActiveIcon } from '../../../assets';
import { MenuItem, SidebarProps } from '../../types';

const menuItems: MenuItem[] = [
  { name: 'Financial Highlights', key: 'financial' },
  { name: 'Details', key: 'details' },
  { name: 'Resources', key: 'resources' },
  { name: 'Projects', key: 'projects' },
  { name: 'Cases', key: 'cases' },
  { name: 'Activities', key: 'activities' },
  { name: 'Notes', key: 'notes' },
  { name: 'Attachments', key: 'attachments' },
  { name: 'Checklist', key: 'checklist' },
  { name: 'Timesheet', key: 'timesheet' },
  { name: 'Imports', key: 'imports' },
];

const Sidebar: React.FC<SidebarProps> = ({ activeKey, onSelect }) => {
  return (
    <div className='w-full bg-white border-r border-gray-300 p-4'>
      <h2 className='text-xl font-semibold mb-6'>Related List</h2>
      <ul className='space-y-2'>
        {menuItems.map((item) => (
          <li key={item.key}>
            <button
              onClick={() => onSelect(item.key)}
              className={`w-full flex items-center gap-2 text-left px-3 py-2 rounded hover:bg-[#0BBFB726] ${
                activeKey === item.key
                  ? 'bg-[#0BBFB726] font-semibold'
                  : 'font-normal'
              }`}
            >
              {item.name}
              {activeKey === item.key && (
                <img src={adminSubmenuActiveIcon} alt='active' />
              )}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
